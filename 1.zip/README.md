# Carrito
Fvor de correr el archivo de base.sql primero y luego insert.sql
Repo de PW2_Nodejs y BD
