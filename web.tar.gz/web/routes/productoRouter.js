import express from 'express';
import {
    crearProducto,
    obtenerProductos,
    obtenerProductoPorId,
    actualizarProducto,
    eliminarProducto,
} from '../controllers/productosController.js';

const router = express.Router();

// CRUD de productos
router.post('/productos', crearProducto);
router.get('/productos', obtenerProductos);
router.get('/productos/:id_producto', obtenerProductoPorId);
router.put('/productos/:id_producto', actualizarProducto);
router.delete('/productos/:id_producto', eliminarProducto);

export default router;
